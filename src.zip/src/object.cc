#include "object.h"

#include <iterator>

namespace cilly {

std::string ObjList::ToRepr() const {
  std::string s;
  s += "[";
  int n = static_cast<int>(element.size());
  for (int i = 0; i < n; i++) {
    s += element[i].ToRepr();
    if (i != n - 1) {
      s += ", ";
    }
  }
  s += "]";
  return s;
}

Value ObjDict::Get(const std::string& key) const {
  auto it = entries_.find(key);
  if (it != entries_.end())
    return it->second;
  else
    return Value::Null();
}

std::string ObjDict::ToRepr() const {
  std::string s;
  s += "{ ";
  for (auto i = entries_.begin(); i != entries_.end(); i++) {
    s += "\"";
    s += i->first;
    s += "\" : ";
    s += i->second.ToRepr();
    // �ж��ǲ������һ��
    if (std::next(i) != entries_.end()) {
      s += ", ";
    }
  }
  s += " }";
  return s;
}

std::string ObjClass::ToRepr() const {
  std::string s;
  s += "<class ";
  s += name;
  s += ">";
  return s;
}

std::string ObjInstance::ToRepr() const {
  std::string s;
  s += "<";
  s += klass->Name();
  s += " Instance>";
  return s;
}

}  // namespace cilly