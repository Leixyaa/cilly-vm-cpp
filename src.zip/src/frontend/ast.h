#ifndef CILLY_VM_CPP_AST_H_
#define CILLY_VM_CPP_AST_H_

#include <initializer_list>
#include <memory>
#include <string>
#include <vector>

#include "lexer.h"  // Ϊ���� Token �������

namespace cilly {

// ǰ�������������ñ����򻯡�
struct Expr;
struct Stmt;

using ExprPtr = std::unique_ptr<Expr>;
using StmtPtr = std::unique_ptr<Stmt>;

// ======================
// ����ʽ��Expression��
// ======================

struct Expr {
  enum class Kind {
    kLiteral,   // �����������֡�true��false��null
    kVariable,  // �������ã�x
    kBinary,    // ��Ԫ����ʽ��a + b
    kList,
    kDict,
    kIndex,
    kUnaryExpr,
    kCall,  // �������ñ���ʽ �磺print add(x,y);
    kGetProp,
  };

  explicit Expr(Kind kind) : kind(kind) {}
  virtual ~Expr() = default;

  Kind kind;
};

// ���������ͣ����� / ���� / null
struct LiteralExpr : public Expr {
  enum class LiteralKind {
    kNumber,
    kBool,
    kNull,
    kString,

  };

  LiteralExpr(LiteralKind literal_kind, std::string lexeme) :
      Expr(Kind::kLiteral),
      literal_kind(literal_kind),
      lexeme(std::move(lexeme)) {}

  LiteralKind literal_kind;
  // Դ������ı������� "123" / "true" / "null"
  std::string lexeme;
};

// �������ã��������ʽ����� x��y_1 ����
struct VariableExpr : public Expr {
  explicit VariableExpr(Token name) :
      Expr(Kind::kVariable), name(std::move(name)) {}

  // ��¼��������Ӧ�� token�������Ժ󱨴����кš��кţ�
  Token name;
};

struct CallExpr : public Expr {
  explicit CallExpr(ExprPtr callee_, std::vector<ExprPtr> arg_, Token paran_) :
      Expr(Kind::kCall),
      callee(std::move(callee_)),
      arg(std::move(arg_)),
      paran(paran_) {}

  ExprPtr callee;
  std::vector<ExprPtr> arg;
  Token paran;  // ���ڱ���
};

// ��Ԫ����ʽ��left op right������ 1 + 2 �� x == 3
struct BinaryExpr : public Expr {
  BinaryExpr(ExprPtr left, Token op, ExprPtr right) :
      Expr(Kind::kBinary),
      left(std::move(left)),
      op(std::move(op)),
      right(std::move(right)) {}

  ExprPtr left;
  Token op;  // �������Ӧ�� token������ +��-��==��
  ExprPtr right;
};

struct ListExpr : public Expr {
  ListExpr(std::vector<ExprPtr> elements_) :
      Expr(Kind::kList), elements(std::move(elements_)) {}
  std::vector<ExprPtr> elements;
};

struct DictExpr : public Expr {
  DictExpr(std::vector<std::pair<std::string, ExprPtr>> entries_) :
      Expr(Kind::kDict), entries(std::move(entries_)) {}
  std::vector<std::pair<std::string, ExprPtr>> entries;
};

struct IndexExpr : public Expr {
  IndexExpr(ExprPtr object_, ExprPtr expr_) :
      Expr(Kind::kIndex), object(std::move(object_)), expr(std::move(expr_)) {}
  ExprPtr object;
  ExprPtr expr;
};

struct UnaryExpr : public Expr {
  UnaryExpr(Token op_, ExprPtr expr_) :
      Expr(Kind::kUnaryExpr), op(std::move(op_)), expr(std::move(expr_)) {}

  Token op;
  ExprPtr expr;
};

struct GetPropExpr : public Expr {
  GetPropExpr(ExprPtr object_, Token name_) :
      Expr(Kind::kGetProp), object(std::move(object_)), name(name_) {}
  ExprPtr object;
  Token name;
};

// ======================
// ��䣨Statement��
// ======================

struct Stmt {
  enum class Kind {
    kVar,          // ����������var x = expr;
    kFun,          // ��������
    kExpr,         // ����ʽ��䣺expr;
    kPrint,        // print ��䣺print expr;
    kBlock,        // ������䣺{ stmt* }
    kAssign,       // ��ֵ��䣺x = expr;
    kIndexAssign,  // ������ֵ��� x[i] = expr;
    kWhile,
    kFor,
    kBreak,
    kContinue,
    kIf,
    kReturn,
    kPropAssign,
    kClass,
  };

  explicit Stmt(Kind kind) : kind(kind) {}
  virtual ~Stmt() = default;

  Kind kind;
};

// var ������var name = initializer;
struct VarStmt : public Stmt {
  VarStmt(Token name, ExprPtr initializer) :
      Stmt(Kind::kVar),
      name(std::move(name)),
      initializer(std::move(initializer)) {}

  Token name;
  // ���� initializer Ϊ�գ�var x; ����������Ժ� Parser ���ƣ�
  ExprPtr initializer;
};

// ����ʽ��䣺expr;
struct ExprStmt : public Stmt {
  explicit ExprStmt(ExprPtr expr) : Stmt(Kind::kExpr), expr(std::move(expr)) {}

  ExprPtr expr;
};

// print ��䣺print expr;
struct PrintStmt : public Stmt {
  explicit PrintStmt(ExprPtr expr) :
      Stmt(Kind::kPrint), expr(std::move(expr)) {}

  ExprPtr expr;
};

// while ���
struct WhileStmt : public Stmt {
  WhileStmt(ExprPtr cond_, StmtPtr body_) :
      Stmt(Kind::kWhile), cond(std::move(cond_)), body(std::move(body_)) {}
  ExprPtr cond;
  StmtPtr body;
};

// for ���
struct ForStmt : public Stmt {
  ForStmt(StmtPtr init_, ExprPtr cond_, StmtPtr step_, StmtPtr body_) :
      Stmt(Kind::kFor),
      init(std::move(init_)),
      cond(std::move(cond_)),
      step(std::move(step_)),
      body(std::move(body_)) {}

  StmtPtr init;
  ExprPtr cond;
  StmtPtr step;
  StmtPtr body;
};

// break ���
struct BreakStmt : public Stmt {
  BreakStmt() : Stmt(Kind::kBreak) {}
};

// continue ���
struct ContinueStmt : public Stmt {
  ContinueStmt() : Stmt(Kind::kContinue) {}
};

// ����飺{ stmt1; stmt2; ... }
struct BlockStmt : public Stmt {
  BlockStmt() : Stmt(Kind::kBlock) {}
  std::vector<StmtPtr> statements;
};

struct FunctionStmt : public Stmt {
  FunctionStmt(Token name_, std::vector<Token> params_,
               std::unique_ptr<BlockStmt> body_) :
      Stmt(Kind::kFun), name(name_), params(params_), body(std::move(body_)) {};

  Token name;
  std::vector<Token> params;
  std::unique_ptr<BlockStmt> body;
};

// ��ֵ���
struct AssignStmt : public Stmt {
  AssignStmt(Token name, ExprPtr expr) :
      Stmt(Kind::kAssign), name(std::move(name)), expr(std::move(expr)) {}

  Token name;
  ExprPtr expr;
};

// ������ֵ���
struct IndexAssignStmt : public Stmt {
  IndexAssignStmt(ExprPtr object_, ExprPtr index_, ExprPtr expr_) :
      Stmt(Kind::kIndexAssign),
      object(std::move(object_)),
      index(std::move(index_)),
      expr(std::move(expr_)) {}

  ExprPtr object;
  ExprPtr index;
  ExprPtr expr;
};

struct IfStmt : public Stmt {
  IfStmt(ExprPtr cond_, StmtPtr then_, StmtPtr else_) :
      Stmt(Kind::kIf),
      cond(std::move(cond_)),
      then_branch(std::move(then_)),
      else_branch(std::move(else_)) {}

  ExprPtr cond;
  StmtPtr then_branch;
  StmtPtr else_branch;
};

struct ReturnStmt : public Stmt {
  ReturnStmt(ExprPtr expr_) : Stmt(Kind::kReturn), expr(std::move(expr_)) {}
  ExprPtr expr;
};

// expr.name = expr;
struct PropAssignStmt : public Stmt {
  PropAssignStmt(ExprPtr object_, Token name_, ExprPtr expr_) :
      Stmt(Kind::kPropAssign),
      object(std::move(object_)),
      name(name_),
      expr(std::move(expr_)) {}
  ExprPtr object;
  Token name;
  ExprPtr expr;
};

struct ClassStmt : public Stmt {
  ClassStmt(Token name_, std::vector<StmtPtr> methods_) :
      Stmt(Kind::kClass), name(name_), methods(std::move(methods_)) {}

  Token name;
  std::vector<StmtPtr> methods;
};

}  // namespace cilly

#endif  // CILLY_VM_CPP_AST_H_
