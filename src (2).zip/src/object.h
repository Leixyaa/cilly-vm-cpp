// object.h
#ifndef CILLY_VM_CPP_OBJECT_H_
#define CILLY_VM_CPP_OBJECT_H_
// �ڴ�����Ȩ
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "value.h"

namespace cilly {

enum class ObjType {
  kString,
  kList,
  kDict,
  kClass,
  kInstance,
  kBoundMethod,
};

class Object {
 public:
  Object(ObjType type, int ref_count) : type_(type), ref_count_(ref_count) {}

  ObjType Type() const { return type_; }
  virtual std::string ToRepr() const { return ""; }

  virtual ~Object() = default;
  // mark bit,next	 // �Ժ������mark bit(GC ��)��ָ��next��

 protected:
  ObjType type_;  // ��ʾ����
  // ��ǰ�׶Σ��������ڴ�������� std::shared_ptr<Object>��
  // ����� ref_count_ ��ʱ��ʹ�ã������Ժ�ʵ���Զ��� GC / ���ü�����
  int ref_count_;
};

class ObjString : public Object {
 public:
  ObjString() : Object(ObjType::kString, 1), value_("") {};

  explicit ObjString(std::string string_value) :
      Object(ObjType::kString, 1), value_(std::move(string_value)) {}

  void Set(const std::string& s) { value_ = s; }

  std::string ToRepr() const override { return value_; }

  ~ObjString() override = default;

 private:
  std::string value_;
};

class ObjList : public Object {
 public:
  ObjList() : Object(ObjType::kList, 1), element() {};

  explicit ObjList(std::vector<Value> elem) :
      Object(ObjType::kList, 1), element(std::move(elem)) {};

  int Size() const { return static_cast<int>(element.size()); }
  void Push(const Value& v) { element.push_back(v); }
  const Value& At(int index) const { return element[index]; }
  void Set(int index, const Value& v) { element[index] = v; }

  std::string ToRepr() const override;

  ~ObjList() override = default;

 private:
  std::vector<Value> element;
};  // List

class ObjDict : public Object {
 public:
  ObjDict() : Object(ObjType::kDict, 1), entries_() {};

  explicit ObjDict(std::unordered_map<std::string, Value> index) :
      Object(ObjType::kDict, 1), entries_(std::move(index)) {}

  // д��/�޸ļ�ֵ
  // ��� key �Ѵ��ڣ��͸���ԭ����ֵ��
  void Set(const std::string& key, const Value& value) {
    entries_[key] = value;
  }

  // ��ѯ�Ƿ����
  bool Has(const std::string& key) const {
    return entries_.find(key) != entries_.end();
  }

  // ��ȡ������ָ�� key ��Ӧ�� Value
  // ��������ڣ��ͷ��� Value::Null()
  Value Get(const std::string& key) const;

  void Erase(const std::string& key) { entries_.erase(key); }

  int Size() const { return static_cast<int>(entries_.size()); }

  std::string ToRepr() const override;

  ~ObjDict() override = default;

 private:
  std::unordered_map<std::string, Value> entries_;

};  // Dic

class ObjClass : public Object {
 public:
  explicit ObjClass(std::string name_) :
      Object(ObjType::kClass, 1), name(std::move(name_)) {}

  const std::string& Name() const { return name; }
  std::string ToRepr() const override;

  void DefineMethod(const std::string& name, int32_t callelabe_index);
  int32_t GetMethodIndex(const std::string& method_name);

  // �̳����
  void SetSuperclass(std::shared_ptr<ObjClass> superclass_);
  const std::shared_ptr<ObjClass> Superclass() const;

 private:
  std::string name;
  std::shared_ptr<ObjClass> superclass;
  std::unordered_map<std::string, int32_t> methods;
};  // Class

class ObjInstance : public Object {
 public:
  explicit ObjInstance(std::shared_ptr<ObjClass> klass_) :
      Object(ObjType::kInstance, 1),
      klass(klass_),
      fields(std::make_unique<ObjDict>()) {}

  std::shared_ptr<ObjClass> Klass() const { return klass; }
  ObjDict* Fields() const { return fields.get(); }
  std::string ToRepr() const override;

 private:
  std::shared_ptr<ObjClass> klass;
  std::unique_ptr<ObjDict> fields;
};

class ObjBoundMethod : public Object {
 public:
  explicit ObjBoundMethod(Value receiver_, int32_t index) :
      Object(ObjType::kBoundMethod, 1), receiver(receiver_), method(index) {}

  const Value& Receiver() { return receiver; }
  int32_t Method() { return method; }

  std::string ToRepr() const override {
    return "<bound_method #" + std::to_string(method) + ">";
  }

 private:
  Value receiver;
  int32_t method;
};

}  // namespace cilly

#endif  // CILLY_VM_CPP_OBJECT_H_