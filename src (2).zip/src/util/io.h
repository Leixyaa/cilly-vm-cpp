#include <fstream>
#include <string>

namespace cilly {

std::string ReadFileToString(const std::string path);

}
