// cilly-vm-cpp
// Author: Leixyaa
// Date: 2024-11-06
// Description: Entry point for testing environment.

#include <chrono>
#include <iostream>

#include "builtins.h"
#include "bytecode_stream.h"
#include "chunk.h"
#include "frontend/generator.h"
#include "frontend/lexer.h"
#include "frontend/parser.h"
#include "function.h"
#include "object.h"
#include "opcodes.h"
#include "stack_stats.h"
#include "util/io.h"
#include "value.h"
#include "vm.h"

// ---------------- Value ��װ�Բ� ----------------
void ValueTest() {
  std::cout << "Value ��װ�Բ� :\n" << std::endl;

  cilly::Value vnull = cilly::Value::Null();
  cilly::Value vtrue = cilly::Value::Bool(true);
  cilly::Value vnum = cilly::Value::Num(10);
  cilly::Value vstr = cilly::Value::Str("hi");

  std::cout << vnull.ToRepr() << std::endl;
  std::cout << vtrue.ToRepr() << std::endl;
  std::cout << vnum.ToRepr() << std::endl;
  std::cout << vstr.ToRepr() << std::endl;
  std::cout << (vnum == cilly::Value::Num(10)) << std::endl;
  std::cout << (vnum == vstr) << std::endl;
  std::cout << "---------------------------------------------\n";
}

// ---------------- Stack ��װ�Բ� ----------------
void StackTest() {
  std::cout << "Stack ��װ�Բ� :\n" << std::endl;

  cilly::StackStats s;
  s.Push(cilly::Value::Num(10));
  s.Push(cilly::Value::Num(10));
  s.Push(cilly::Value::Str("stack_test_"));
  auto v = s.Pop();
  std::cout << s.PushCount() << "," << s.PopCount() << "," << s.Depth() << ","
            << s.MaxDepth() << "," << v.ToRepr() << std::endl;
  std::cout << "---------------------------------------------\n";
}

// ---------------- Chunk ��װ�Բ� ----------------
void ChunkTest() {
  using namespace cilly;
  std::cout << "Chunk ��װ�Բ� :\n" << std::endl;

  Chunk ch;

  int c0 = ch.AddConst(Value::Num(10));
  int c1 = ch.AddConst(Value::Num(20));

  ch.Emit(OpCode::OP_CONSTANT, 1);
  ch.EmitI32(c0, 1);
  ch.Emit(OpCode::OP_CONSTANT, 1);
  ch.EmitI32(c1, 1);
  ch.Emit(OpCode::OP_ADD, 1);
  ch.Emit(OpCode::OP_PRINT, 1);

  std::cout << "CodeSize = " << ch.CodeSize() << "\n";
  std::cout << "ConstSize = " << ch.ConstSize() << "\n\n";

  std::cout << "Code stream (index : value [line]):\n";
  for (int i = 0; i < ch.CodeSize(); ++i) {
    std::cout << "  " << i << " : " << ch.CodeAt(i) << " [line " << ch.LineAt(i)
              << "]\n";
  }

  std::cout << "\nConst pool:\n";
  for (int i = 0; i < ch.ConstSize(); ++i) {
    std::cout << "  " << i << " : " << ch.ConstAt(i).ToRepr() << "\n";
  }
  std::cout << "---------------------------------------------\n";
}

// ---------------- Function ��װ�Բ� ----------------
void FunctionTest() {
  using namespace cilly;
  std::cout << "Function ��װ�Բ� :\n" << std::endl;

  Function fn("main", /*arity=*/0);

  int c0 = fn.AddConst(Value::Num(10));
  int c1 = fn.AddConst(Value::Num(20));

  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_ADD, 1);
  fn.Emit(OpCode::OP_PRINT, 1);

  std::cout << "Function name=" << fn.name() << ", arity=" << fn.arity()
            << "\n";
  std::cout << "CodeSize=" << fn.chunk().CodeSize()
            << ", ConstSize=" << fn.chunk().ConstSize() << "\n";

  for (int i = 0; i < fn.chunk().CodeSize(); ++i) {
    std::cout << "  code[" << i << "]=" << fn.chunk().CodeAt(i) << " @line "
              << fn.chunk().LineAt(i) << "\n";
  }
  for (int i = 0; i < fn.chunk().ConstSize(); ++i) {
    std::cout << "  const[" << i << "]=" << fn.chunk().ConstAt(i).ToRepr()
              << "\n";
  }
  std::cout << "---------------------------------------------\n";
}

//---------------- VM ��Сִ��ѭ���Բ� ----------------
void VMTest() {
  using namespace cilly;
  std::cout << "VMTest:\n";

  Function fn("main", 0);
  fn.SetLocalCount(0);

  int c6 = fn.AddConst(Value::Num(6));
  int c3 = fn.AddConst(Value::Num(3));

  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c6, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c3, 1);
  fn.Emit(OpCode::OP_DIV, 1);

  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect return: 2\n";
  std::cout << "---------------------------------------------\n";
}

//---------------- ����ϵͳ�Բ� ----------------
void VarTest() {
  using namespace cilly;
  std::cout << "VarTest:\n";

  Function fn("main", 0);
  fn.SetLocalCount(2);  // local[0]=a, local[1]=b

  int c20 = fn.AddConst(Value::Num(20));
  int c10 = fn.AddConst(Value::Num(10));

  // a = 20
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c20, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);
  fn.EmitI32(0, 1);

  // b = 10
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c10, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);
  fn.EmitI32(1, 1);

  // return a + b  => 30
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(1, 1);
  fn.Emit(OpCode::OP_ADD, 1);

  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect return: 30\n";
  std::cout << "---------------------------------------------\n";
}

// ---------------- �򵥺��������Բ� ----------------
// �����ú������� 42�����������ò���ӡ
void CallTest() {
  using namespace cilly;
  std::cout << "CallTest:\n";

  // callee(): return 20 + 21
  Function callee("callee", 0);
  callee.SetLocalCount(0);
  int c20 = callee.AddConst(Value::Num(20));
  int c21 = callee.AddConst(Value::Num(21));
  callee.Emit(OpCode::OP_CONSTANT, 1);
  callee.EmitI32(c20, 1);
  callee.Emit(OpCode::OP_CONSTANT, 1);
  callee.EmitI32(c21, 1);
  callee.Emit(OpCode::OP_ADD, 1);
  callee.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  RegisterBuiltins(vm);
  int fid = vm.RegisterFunction(&callee);

  // main: call callee(); return result
  Function fn("main", 0);
  fn.SetLocalCount(0);

  fn.Emit(OpCode::OP_CALL, 1);
  fn.EmitI32(fid, 1);

  fn.Emit(OpCode::OP_RETURN, 1);

  vm.Run(fn);

  std::cout << "Expect return: 41\n";
  std::cout << "---------------------------------------------\n";
}

// ---------------- ��һ�������ĺ��������Բ� ----------------
void CallWithArgTest() {
  using namespace cilly;
  std::cout << "CallWithArgTest:\n";

  // add(a,b): return a + b
  Function add("add", 2);
  add.SetLocalCount(2);  // local[0]=a, local[1]=b

  add.Emit(OpCode::OP_LOAD_VAR, 1);
  add.EmitI32(0, 1);
  add.Emit(OpCode::OP_LOAD_VAR, 1);
  add.EmitI32(1, 1);
  add.Emit(OpCode::OP_ADD, 1);
  add.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  RegisterBuiltins(vm);
  int fid = vm.RegisterFunction(&add);

  // main: return add(20, 21)
  Function fn("main", 0);
  fn.SetLocalCount(0);
  int c20 = fn.AddConst(Value::Num(20));
  int c21 = fn.AddConst(Value::Num(21));

  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c20, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c21, 1);

  fn.Emit(OpCode::OP_CALL, 1);
  fn.EmitI32(fid, 1);

  fn.Emit(OpCode::OP_RETURN, 1);

  vm.Run(fn);

  std::cout << "Expect return: 41\n";
  std::cout << "---------------------------------------------\n";
}

// ---------------- ��������Բ� ----------------
void Eqtest() {
  using namespace cilly;
  std::cout << "Eqtest:\n";

  Function fn("main", 0);
  fn.SetLocalCount(0);

  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));

  // return (1 == 2) => false
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_EQ, 1);

  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect return: false\n";
  std::cout << "---------------------------------------------\n";
}

void ForLoopTest() {
  using namespace cilly;
  std::cout << "for loop opcode smoke:\n" << std::endl;

  Function fn("for_test", 0);
  fn.SetLocalCount(1);  // local[0] = i

  int c0 = fn.AddConst(Value::Num(0));
  int c1 = fn.AddConst(Value::Num(1));
  int c3 = fn.AddConst(Value::Num(3));

  // i = 0
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c0, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);
  fn.EmitI32(0, 1);

  int loop_start = fn.CodeSize();

  // cond: i < 3
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c3, 1);
  fn.Emit(OpCode::OP_LESS, 1);

  // if false -> end_label (patch later)
  fn.Emit(OpCode::OP_JUMP_IF_FALSE, 1);
  int end_label_pos = fn.CodeSize();
  fn.EmitI32(0, 1);

  // body: print(i)
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_PRINT, 1);
  // ��Ҫ OP_POP��PRINT �Ѿ� Pop ��

  // i = i + 1
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_ADD, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);
  fn.EmitI32(0, 1);

  // jump back
  fn.Emit(OpCode::OP_JUMP, 1);
  fn.EmitI32(loop_start, 1);

  // patch end label
  fn.PatchI32(end_label_pos, fn.CodeSize());

  // return i (expect 3)
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect print: 0,1,2; return: 3\n";
  std::cout << "---------------------------------------------\n";
}

// ---------------- ������ת�����Բ� ----------------
void IfTest() {
  using namespace cilly;

  std::cout << "������ת�����Բ�:\n" << std::endl;

  Function fn("if_test", 0);
  fn.SetLocalCount(0);

  // ����
  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));
  int c888 = fn.AddConst(Value::Num(888));
  int c999 = fn.AddConst(Value::Num(999));

  int cnull = fn.AddConst(
      Value::Null());  // �����������벻�����ĳ� Value::Bool(false)

  // ��� (1 == 2)
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_EQ, 1);  // ջ�� = false

  // JUMP_IF_FALSE <else_label>
  fn.Emit(OpCode::OP_JUMP_IF_FALSE, 1);
  int if_else_pos = fn.CodeSize();
  fn.EmitI32(0, 1);

  // then: print(999)
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c999, 1);
  fn.Emit(OpCode::OP_PRINT, 1);

  // JUMP end
  fn.Emit(OpCode::OP_JUMP, 1);
  int if_end_pos = fn.CodeSize();
  fn.EmitI32(0, 1);

  // patch else
  fn.PatchI32(if_else_pos, fn.CodeSize());

  // else: print(888)
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c888, 1);
  fn.Emit(OpCode::OP_PRINT, 1);

  // patch end
  fn.PatchI32(if_end_pos, fn.CodeSize());

  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(cnull, 1);
  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect print: 888; return: null\n";
  std::cout << "---------------------------------------------\n";
}

// ---------------- odd/even ���ݹ��Բ� ----------------
void OddEvenTest() {
  using namespace cilly;
  std::cout << "odd/even ���ݹ��Բ�:\n" << std::endl;

  Function odd_fn("odd", 1);
  Function even_fn("even", 1);
  Function main_fn("main", 0);

  odd_fn.SetLocalCount(1);   // n
  even_fn.SetLocalCount(1);  // n
  main_fn.SetLocalCount(0);

  VM vm;
  RegisterBuiltins(vm);

  int odd_id = vm.RegisterFunction(&odd_fn);
  int even_id = vm.RegisterFunction(&even_fn);

  // ===== even(n): if (n==0) return true; else return odd(n-1) =====
  int even_c0 = even_fn.AddConst(Value::Num(0));
  int even_c1 = even_fn.AddConst(Value::Num(1));
  int even_true = even_fn.AddConst(Value::Bool(true));

  even_fn.Emit(OpCode::OP_LOAD_VAR, 1);
  even_fn.EmitI32(0, 1);
  even_fn.Emit(OpCode::OP_CONSTANT, 1);
  even_fn.EmitI32(even_c0, 1);
  even_fn.Emit(OpCode::OP_EQ, 1);

  even_fn.Emit(OpCode::OP_JUMP_IF_FALSE, 1);
  int even_else_pos = even_fn.CodeSize();
  even_fn.EmitI32(0, 1);

  even_fn.Emit(OpCode::OP_CONSTANT, 1);
  even_fn.EmitI32(even_true, 1);
  even_fn.Emit(OpCode::OP_RETURN, 1);

  even_fn.PatchI32(even_else_pos, even_fn.CodeSize());

  even_fn.Emit(OpCode::OP_LOAD_VAR, 1);
  even_fn.EmitI32(0, 1);
  even_fn.Emit(OpCode::OP_CONSTANT, 1);
  even_fn.EmitI32(even_c1, 1);
  even_fn.Emit(OpCode::OP_SUB, 1);
  even_fn.Emit(OpCode::OP_CALL, 1);
  even_fn.EmitI32(odd_id, 1);
  even_fn.Emit(OpCode::OP_RETURN, 1);

  // ===== odd(n): if (n==0) return false; else return even(n-1) =====
  int odd_c0 = odd_fn.AddConst(Value::Num(0));
  int odd_c1 = odd_fn.AddConst(Value::Num(1));
  int odd_false = odd_fn.AddConst(Value::Bool(false));

  odd_fn.Emit(OpCode::OP_LOAD_VAR, 1);
  odd_fn.EmitI32(0, 1);
  odd_fn.Emit(OpCode::OP_CONSTANT, 1);
  odd_fn.EmitI32(odd_c0, 1);
  odd_fn.Emit(OpCode::OP_EQ, 1);

  odd_fn.Emit(OpCode::OP_JUMP_IF_FALSE, 1);
  int odd_else_pos = odd_fn.CodeSize();
  odd_fn.EmitI32(0, 1);

  odd_fn.Emit(OpCode::OP_CONSTANT, 1);
  odd_fn.EmitI32(odd_false, 1);
  odd_fn.Emit(OpCode::OP_RETURN, 1);

  odd_fn.PatchI32(odd_else_pos, odd_fn.CodeSize());

  odd_fn.Emit(OpCode::OP_LOAD_VAR, 1);
  odd_fn.EmitI32(0, 1);
  odd_fn.Emit(OpCode::OP_CONSTANT, 1);
  odd_fn.EmitI32(odd_c1, 1);
  odd_fn.Emit(OpCode::OP_SUB, 1);
  odd_fn.Emit(OpCode::OP_CALL, 1);
  odd_fn.EmitI32(even_id, 1);
  odd_fn.Emit(OpCode::OP_RETURN, 1);

  // ===== main: print(even(3)); v=odd(3); print(v); return v =====
  int c3 = main_fn.AddConst(Value::Num(3));

  // print(even(3))
  main_fn.Emit(OpCode::OP_CONSTANT, 1);
  main_fn.EmitI32(c3, 1);
  main_fn.Emit(OpCode::OP_CALL, 1);
  main_fn.EmitI32(even_id, 1);
  main_fn.Emit(OpCode::OP_PRINT, 1);

  // v = odd(3)
  main_fn.Emit(OpCode::OP_CONSTANT, 1);
  main_fn.EmitI32(c3, 1);
  main_fn.Emit(OpCode::OP_CALL, 1);
  main_fn.EmitI32(odd_id, 1);

  // print(v) but keep v for return
  main_fn.Emit(OpCode::OP_DUP, 1);
  main_fn.Emit(OpCode::OP_PRINT, 1);

  // return v
  main_fn.Emit(OpCode::OP_RETURN, 1);

  vm.Run(main_fn);

  std::cout << "Expect print: true, true; return: true (odd(3))\n";
  std::cout << "---------------------------------------------\n";
}

// ---------------- �Ƚ�ָ���Բ� ----------------
void CompareTest() {
  using namespace cilly;
  std::cout << "CompareTest:\n";

  Function fn("main", 0);
  fn.SetLocalCount(0);

  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));

  // return (1 < 2) => true
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_LESS, 1);

  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect return: true\n";
  std::cout << "---------------------------------------------\n";
}

//---------------- �������ļ���д ----------------
void StreamTest() {
  std::cout << "�������ļ���д..." << std::endl;
  using namespace cilly;
  // д�����
  {
    BytecodeWriter writer("test.bin");  // ����Ŀ¼������ test.bin
    writer.Write<int>(12345);           // д������
    writer.Write<double>(3.14159);      // д�븡����
    writer.WriteString("Hello C++");    // д���ַ���
  }  // writer �������ļ��Զ��ر�

  // ��ȡ����
  {
    BytecodeReader reader("test.bin");
    int i = reader.Read<int>();
    double d = reader.Read<double>();
    std::string s = reader.ReadString();

    // ��֤
    if (i == 12345 && d == 3.14159 && s == "Hello C++") {
      std::cout << "�ɹ�д���ȡ��\n";
    } else {
      std::cout << "ʧ�ܣ��ļ����Ͳ�ƥ�䣡\n";
      std::cout << "Read: " << i << ", " << d << ", " << s << "\n";
    }
  }
  std::cout << "---------------------------------------------\n";
}

void ValueSerializationTest() {
  std::cout << "ֵ���л�����...\n";

  // ׼�����ݣ����� Null, Bool, Num, Str ������
  std::vector<cilly::Value> values;
  values.push_back(cilly::Value::Null());
  values.push_back(cilly::Value::Bool(true));
  values.push_back(cilly::Value::Num(123.456));
  values.push_back(cilly::Value::Str("C++ Variant Magic"));

  // д���ļ�
  {
    cilly::BytecodeWriter writer("value_test.bin");
    // �ֶ�ģ��д��һ�� vector �Ĺ���
    writer.Write<int32_t>(values.size());
    for (const auto& v : values) {
      v.Save(writer);  // ���� Save
    }
  }

  // ��ȡ�ļ�
  {
    cilly::BytecodeReader reader("value_test.bin");
    int32_t count = reader.Read<int32_t>();

    if (count != values.size())
      std::cout << "FAIL: ������ƥ��!\n";

    for (int i = 0; i < count; ++i) {
      cilly::Value loaded = cilly::Value::Load(reader);  // ���� Load

      // ��֤�Ƿ����
      if (loaded != values[i]) {
        std::cout << "FAIL: ͬһ���� Value ��ƥ�� " << i << "\n";
        std::cout << "Expected: " << values[i].ToRepr() << "\n";
        std::cout << "Got: " << loaded.ToRepr() << "\n";
        return;
      }
    }
  }

  std::cout << "����Valueֵ������ȷ����!\n";
  std::cout << "---------------------------------------------\n";
}

void ChunkSerializationTest() {
  using namespace cilly;

  std::cout << "Chunk ���л��Բ�..." << std::endl;

  //  ����һ���򵥵� Function�������������һ�ο�ִ�е��ֽ���
  //  ((0 + 1) - 2) + 1��Ȼ���ӡ����� return��
  Function fn("main", 0);
  fn.SetLocalCount(0);

  // �����أ�0, 1, 2
  int c0 = fn.AddConst(Value::Num(0));
  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));

  // �����ֽ��룺
  // push 0
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c0, 1);

  // push 1
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);

  // 0 + 1
  fn.Emit(OpCode::OP_ADD, 1);

  // push 2
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);

  // (0 + 1) - 2
  fn.Emit(OpCode::OP_SUB, 1);

  // push 1
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);

  // ((0 + 1) - 2) + 1
  fn.Emit(OpCode::OP_ADD, 1);

  // print ���
  fn.Emit(OpCode::OP_PRINT, 1);

  // return
  fn.Emit(OpCode::OP_RETURN, 1);

  // �� fn ��Ӧ�� Chunk ���л����ļ�
  {
    BytecodeWriter writer("chunk_test.bin");
    fn.chunk().Save(writer);
  }

  // ���ļ��з����л���һ���µ� Chunk
  BytecodeReader reader("chunk_test.bin");
  Chunk loaded = Chunk::Load(reader);

  // ���ζԱȣ����볤�ȡ������س���
  if (fn.CodeSize() != loaded.CodeSize()) {
    std::cout << "���󣺴��볤�Ȳ�һ��" << std::endl;
    return;
  }

  if (fn.ConstSize() != loaded.ConstSize()) {
    std::cout << "���󣺳���������һ��" << std::endl;
    return;
  }

  // �Ա�ÿһ���ֽ���ָ��/������
  for (int i = 0; i < fn.CodeSize(); ++i) {
    if (fn.chunk().CodeAt(i) != loaded.CodeAt(i)) {
      std::cout << "���󣺵� " << i << " ���ֽ��벻һ��" << std::endl;
      return;
    }
  }

  // �Ա�ÿһ������ֵ
  for (int i = 0; i < fn.ConstSize(); ++i) {
    if (fn.chunk().ConstAt(i) != loaded.ConstAt(i)) {
      std::cout << "���󣺵� " << i << " ��������һ��" << std::endl;
      return;
    }
  }

  // �Ա�ÿһ���к�
  for (int i = 0; i < fn.CodeSize(); ++i) {
    if (fn.chunk().LineAt(i) != loaded.LineAt(i)) {
      std::cout << "���󣺵� " << i << " ���кŲ�һ��" << std::endl;
      return;
    }
  }

  std::cout << "Chunk ���л�ͨ����" << std::endl;
}

void FunctionSerializationTest() {
  using namespace cilly;

  std::cout << "Function ���л��Բ�..." << std::endl;

  // ����һ���򵥵ĺ�����((0 + 1) - 2) + 1��Ȼ�� print �� return
  Function fn("main", 0);
  fn.SetLocalCount(0);

  // �����أ�0, 1, 2
  int c0 = fn.AddConst(Value::Num(0));
  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));

  // �����ֽ��룺
  // push 0
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c0, 1);

  // push 1
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);

  // 0 + 1
  fn.Emit(OpCode::OP_ADD, 1);

  // push 2
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);

  // (0 + 1) - 2
  fn.Emit(OpCode::OP_SUB, 1);

  // push 1
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);

  // ((0 + 1) - 2) + 1
  fn.Emit(OpCode::OP_ADD, 1);

  // ��ӡ���
  fn.Emit(OpCode::OP_PRINT, 1);

  // ����
  fn.Emit(OpCode::OP_RETURN, 1);

  // �� Function ���л����������ļ�
  {
    BytecodeWriter writer("function_test.bin");
    fn.Save(writer);
  }

  // �Ӷ������ļ��з����л��õ�һ���µ� Function
  BytecodeReader reader("function_test.bin");
  Function loaded = Function::Load(reader);

  // ��麯��Ԫ��Ϣ�Ƿ�һ�£����� / �βθ��� / �ֲ�����������
  if (fn.name() != loaded.name()) {
    std::cout << "���󣺺������Ʋ�һ��" << std::endl;
    return;
  }

  if (fn.arity() != loaded.arity()) {
    std::cout << "�����β�������һ��" << std::endl;
    return;
  }

  if (fn.LocalCount() != loaded.LocalCount()) {
    std::cout << "���󣺾ֲ�����������һ��" << std::endl;
    return;
  }

  // ��һ�����ײ� Chunk�������� + ָ���� + �к���Ϣ
  const Chunk& ch0 = fn.chunk();
  const Chunk& ch1 = loaded.chunk();

  if (ch0.ConstSize() != ch1.ConstSize()) {
    std::cout << "���󣺳����ش�С��һ��" << std::endl;
    return;
  }

  if (ch0.CodeSize() != ch1.CodeSize()) {
    std::cout << "����ָ�����г��Ȳ�һ��" << std::endl;
    return;
  }

  // �Ա�ÿһ������
  for (int i = 0; i < ch0.ConstSize(); ++i) {
    if (ch0.ConstAt(i) != ch1.ConstAt(i)) {
      std::cout << "���󣺳��������ݲ�һ�£����� = " << i << std::endl;
      return;
    }
  }

  // �Ա�ÿһ��ָ��
  for (int i = 0; i < ch0.CodeSize(); ++i) {
    if (ch0.CodeAt(i) != ch1.CodeAt(i)) {
      std::cout << "����ָ�����в�һ�£����� = " << i << std::endl;
      return;
    }
  }

  // �Ա�ÿһ���кţ������������ CodeSize һ�£�
  for (int i = 0; i < ch0.CodeSize(); ++i) {
    if (ch0.LineAt(i) != ch1.LineAt(i)) {
      std::cout << "�����к���Ϣ��һ�£����� = " << i << std::endl;
      return;
    }
  }

  std::cout << "Function ���л�ͨ����" << std::endl;
}

void VarValueSemanticsTest() {
  using namespace cilly;
  std::cout << "����ֵ�����Բ�...\n";

  Function fn("main", 0);
  fn.SetLocalCount(2);  // local[0] = a, local[1] = b

  // �����أ�1 �� 2
  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));

  // var a = 1;
  fn.Emit(OpCode::OP_CONSTANT, 1);  // push 1
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);  // a = 1
  fn.EmitI32(0, 1);                  // local[0]

  // var b = a;
  fn.Emit(OpCode::OP_LOAD_VAR, 1);  // push a
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);  // b = a
  fn.EmitI32(1, 1);                  // local[1]

  // b = 2;
  fn.Emit(OpCode::OP_CONSTANT, 1);  // push 2
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);  // b = 2
  fn.EmitI32(1, 1);                  // local[1]

  // print(a);
  fn.Emit(OpCode::OP_LOAD_VAR, 1);  // push a
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_PRINT, 1);  // ��ӡ a��������1��

  // return
  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "����ֵ�����Բ������Ԥ�������1��\n";
  std::cout << "---------------------------------------------\n";
}

void ObjSmokeTest() {
  using namespace cilly;
  std::cout << "����ObjList ObjString �Ƿ�ɹ�����\n";
  std::cout << "����ObjList\n";
  auto obj = std::make_shared<ObjList>();
  obj->Push(Value::Num(1));
  obj->Push(Value::Str("hello"));
  obj->Push(Value::Bool(true));
  std::cout << obj->ToRepr() << std::endl;

  Value v1 = Value::Obj(obj);
  std::cout << v1.ToRepr() << std::endl;

  std::cout << "����ObjString\n";
  auto obj_string = std::make_shared<ObjString>();
  obj_string->Set("hello");
  std::cout << obj_string->ToRepr() << std::endl;
  Value v2 = Value::Obj(obj_string);
  std::cout << v2.ToRepr() << std::endl;

  std::cout << "����ObjDict\n";
  std::unordered_map<std::string, Value> index;
  index["a"] = Value::Num(1);                        // a : 1
  index["b"] = Value::Num(2);                        // b : 2
  auto obj_dict = std::make_shared<ObjDict>(index);  // ����ObjDict
  obj_dict->Set("c", Value::Num(3));                 // c : 3
  if (obj_dict->Has("a")) {                          // ���� a
    std::cout << "���� a" << std::endl;
  }
  if (!obj_dict->Has("d")) {  // ���� d
    std::cout << "������ d" << std::endl;
  }
  std::cout << (obj_dict->Get("a")).ToRepr() << std::endl;  // ���� a �ؼ��ֵ�ֵ
  std::cout << (obj_dict->Get("d")).ToRepr()
            << std::endl;  // ���� d �ؼ��ֵ�ֵ(Null)
  obj_dict->Erase("a");    // ɾ�� a
  if (!obj_dict->Has("a")) {
    std::cout << "������ a" << std::endl;
  }
  std::cout << obj_dict->Size() << std::endl;  // ���س��� 2
  std::cout << obj_dict->ToRepr() << std::endl;
  std::cout << "---------------------------------------------\n";
}

void ListOpcodeTest() {
  using namespace cilly;
  std::cout << "List opcode smoke:\n";

  VM vm;

  Function fn("main", 0);
  fn.SetLocalCount(1);  // local[0] = list

  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));
  int c0 = fn.AddConst(Value::Num(0));

  // list = []
  fn.Emit(OpCode::OP_LIST_NEW, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);
  fn.EmitI32(0, 1);

  // push 1, 2
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_LIST_PUSH, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_LIST_PUSH, 1);

  // print(len(list))  -> expect 2
  fn.Emit(OpCode::OP_LIST_LEN, 1);
  fn.Emit(OpCode::OP_PRINT, 1);
  // ��Ҫ OP_POP��PRINT �Ѿ� Pop ��

  // list[0] = 2
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_INDEX_SET, 1);

  // v = list[0]
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c0, 1);
  fn.Emit(OpCode::OP_INDEX_GET, 1);

  // print(v) but keep v for return
  fn.Emit(OpCode::OP_DUP, 1);
  fn.Emit(OpCode::OP_PRINT, 1);

  // return v  -> expect 2
  fn.Emit(OpCode::OP_RETURN, 1);

  vm.Run(fn);

  std::cout << "Expect print: 2, 2; return: 2\n";
  std::cout << "---------------------------------------------\n";
}

void DictOpcodeTest() {
  using namespace cilly;
  std::cout << "Dict opcode smoke:\n" << std::endl;

  Function fn("main", 0);
  fn.SetLocalCount(1);  // local[0] = dict

  int c1 = fn.AddConst(Value::Num(1));
  int c2 = fn.AddConst(Value::Num(2));
  int c_a = fn.AddConst(Value::Str("a"));
  int c_b = fn.AddConst(Value::Str("b"));
  int c_c = fn.AddConst(Value::Str("c"));

  // dict = {}
  fn.Emit(OpCode::OP_DICT_NEW, 1);
  fn.Emit(OpCode::OP_STORE_VAR, 1);
  fn.EmitI32(0, 1);

  // dict["a"] = 1; dict["b"] = 2
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_DUP, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c_a, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c1, 1);
  fn.Emit(OpCode::OP_INDEX_SET, 1);

  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c_b, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_INDEX_SET, 1);

  // print(dict["a"]) -> expect 1
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c_a, 1);
  fn.Emit(OpCode::OP_INDEX_GET, 1);
  fn.Emit(OpCode::OP_PRINT, 1);
  // ��Ҫ OP_POP��PRINT �Ѿ� Pop ��

  // dict["a"] = 2; print(dict["a"]) -> expect 2
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_DUP, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c_a, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c2, 1);
  fn.Emit(OpCode::OP_INDEX_SET, 1);

  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c_a, 1);
  fn.Emit(OpCode::OP_INDEX_GET, 1);
  fn.Emit(OpCode::OP_PRINT, 1);
  // ��Ҫ OP_POP��PRINT �Ѿ� Pop ��

  // has("c") -> expect false
  fn.Emit(OpCode::OP_LOAD_VAR, 1);
  fn.EmitI32(0, 1);
  fn.Emit(OpCode::OP_CONSTANT, 1);
  fn.EmitI32(c_c, 1);
  fn.Emit(OpCode::OP_DICT_HAS, 1);

  // print(has) but keep for return
  fn.Emit(OpCode::OP_DUP, 1);
  fn.Emit(OpCode::OP_PRINT, 1);

  // return has -> expect false
  fn.Emit(OpCode::OP_RETURN, 1);

  VM vm;
  vm.Run(fn);

  std::cout << "Expect print: 1, 2, false; return: false\n";
  std::cout << "---------------------------------------------\n";
}

void LexerSmokeTest() {
  using namespace cilly;

  std::string source = "var _x = 1; print _x; // comment\n";
  Lexer lexer(source);
  auto tokens = lexer.ScanAll();

  std::cout << "Lexer �Բ⣺token ���� = " << tokens.size() << std::endl;
  if (!tokens.empty()) {
    std::cout << "��һ�� token kind (int) = "
              << static_cast<int>(tokens[0].kind) << ", lexeme = \""
              << tokens[0].lexeme << "\"" << std::endl;
  }
  std::cout << "---------------------------------------------\n";
}

void ParserExprSmokeTest() {
  using namespace cilly;

  std::cout << "Parser ����ʽ�Բ�:\n";

  // Դ���ַ��������ǡ��Բ����롱��
  std::string source =
      "print 1 + 2 * 3;\n"
      "print (1 + 2) * 3;\n"
      "var x = 10;\n"
      "print x + 5 * 2;\n"
      "print -x + 3;\n";

  // �ȴʷ����� �� tokens
  Lexer lexer(source);
  std::vector<Token> tokens = lexer.ScanAll();

  // ���﷨���� �� AST������б���
  Parser parser(std::move(tokens));
  std::vector<StmtPtr> program = parser.ParseProgram();

  // ��ӡ����Ϣȷ�Ͻ����ɹ�
  std::cout << "�����ɹ���������� = " << program.size() << "\n";
  std::cout << "---------------------------------------------\n";
}

void FrontendEndToEndTest() {
  using namespace cilly;

  std::cout << "ǰ�ˡ�VM ȫ��·�Բ�:\n";

  std::string source =
      // A. �ع飺����/��ֵ/����
      "var x = 1;\n"
      "print x;\n"
      "x = x + 1;\n"
      "print x;\n"
      "x = x * 10;\n"
      "print x;\n"

      // B. List ������
      "print [];\n"
      "print [1, 2, 3];\n"
      "print [x, x + 1, x * 2, (x - 3) / 7];\n"

      // C. Dict ��������key �������ַ�����
      "print {};\n"
      "print {\"a\": 1};\n"
      "print {\"a\": x, \"b\": x + 1, \"c\": x * 2};\n"

      // D. Bool / Null
      "print true;\n"
      "print false;\n"
      "print null;\n"
      "print [true, null, false];\n"
      "print {\"t\": true, \"n\": null};\n"

      // E. ��ϣ�dict value �� list
      "print {\"nums\": [x, x + 1, x + 2], \"double\": x * 2};\n"

      // F. ��������
      "var a = [10, 20, 30];\n"
      "print a[0];\n"
      "print a[2];\n"
      "var d = {\"a\": 1, \"b\": 2};\n"
      "print d[\"a\"];\n"
      "print d[\"b\"];\n"
      "print {\"nums\": a}[\"nums\"][1];\n";

  // �ʷ�����
  Lexer lexer(source);
  std::vector<Token> tokens_ = lexer.ScanAll();

  // �﷨����
  Parser parser(tokens_);
  std::vector<StmtPtr> program = parser.ParseProgram();

  // �����ֽ���
  Generator generator;
  Function main = generator.Generate(program);

  VM vm;
  vm.Run(main);
  std::cout << "---------------------------------------------\n";
}

void FrontendEndToEndBlockTest() {
  using namespace cilly;

  std::cout << "ǰ�ˡ�VM ȫ��·�Բ�:\n";

  std::string source =
      "var a = [10, 20, 30];\n"
      "a[1] = 99;\n"
      "print a;\n"  // [10, 99, 30]

      "var d = {\"x\": 1};\n"
      "d[\"x\"] = 42;\n"
      "print d;\n"         // { "x" : 42 }
      "print d[\"x\"];\n"  // 42

      "var x = 1;\n"
      "if (x == 0) print 0;\n"
      "else if (x == 1) print 1;\n"
      "else print 2;\n"  // 1

      "var i = 0;\n"
      "while (i < 6) {\n"
      "  i = i + 1;\n"
      "  if (i == 3) continue;\n"
      "  if (i == 5) break;\n"
      "  print i;\n"
      "}\n"  // 1 2 4

      "var j = 0;\n"
      "for (j = 0; j < 6; j = j + 1) {\n"
      "  if (j == 2) continue;\n"
      "  if (j == 4) break;\n"
      "  print j;\n"
      "}\n"  // 0 1 3

      "var outer = 0;\n"
      "while (outer < 2) {\n"
      "  var inner = 0;\n"
      "  while (inner < 3) {\n"
      "    inner = inner + 1;\n"
      "    if (inner == 2) continue;\n"
      "    break;\n"
      "  }\n"
      "  print outer;\n"
      "  outer = outer + 1;\n"
      "}\n";  // 0 1

  // �ʷ�����
  Lexer lexer(source);
  std::vector<Token> tokens_ = lexer.ScanAll();

  // �﷨����
  Parser parser(tokens_);
  std::vector<StmtPtr> program = parser.ParseProgram();

  // �����ֽ���
  Generator generator;
  Function main = generator.Generate(program);

  VM vm;
  vm.Run(main);
  std::cout << "---------------------------------------------\n";
}

void FrontendETESmokeTest() {
  using namespace cilly;

  std::cout << "ǰ�ˡ�VM ȫ��·�Բ�:\n";

  /*std::string source =
   * ReadFileToString("D:/dev/cilly-vm-cpp/cilly_vm_cpp/file.txt");      */

  std::string source = R"(
var x = 1;
print(x);

{
  var x = 2;
  var y = x + 3;
  print(x);
  print(y);
}

print(x);

{
  var z = 10;
  print(z);
  print(x);
}

print(x);
)";

  // �ʷ�����
  Lexer lexer(source);
  std::vector<Token> tokens_ = lexer.ScanAll();

  // �﷨����
  Parser parser(tokens_);
  std::vector<StmtPtr> program = parser.ParseProgram();

  // �����ֽ���
  Generator generator;
  Function main = generator.Generate(program);

  VM vm;

  for (const auto& fnptr : generator.Functions()) {
    vm.RegisterFunction(fnptr.get());  // ע�����б���ĺ���
  }

  vm.Run(main);
  std::cout << "---------------------------------------------\n";
}

void ScopeAllFeatureSmokeTest() {
  using namespace cilly;

  std::cout << "===== Scope / Block / Loop ȫ����ð�̲��� =====\n";

  std::string source = R"(

  // ---------- 1. �������� ----------
  var x = 1;
  print x;        // 1

  // ---------- 2. block shadow ----------
  {
    var x = 2;
    var y = x + 10;
    print x;      // 2
    print y;      // 12
  }

  print x;        // 1����� x ��Ӧ����Ⱦ��

  // ---------- 3. if / else ������ ----------
  if (x == 1) {
    var a = 100;
    print a;      // 100
  } else {
    var a = 200;
    print a;
  }

  // ---------- 4. while + continue ----------
  var i = 0;
  while (i < 5) {
    i = i + 1;
    var t = i * 10;

    if (i == 2) continue;

    print t;      // 10, 30, 40 , 50
  }

  // ---------- 5. while + break ----------
  var j = 0;
  while (true) {
    j = j + 1;
    var k = j + 100;

    if (j == 3) break;

    print k;      // 101, 102
  }

  print j;        // 3

  // ---------- 6. for loop scope ----------
  for (var m = 0; m < 5; m = m + 1) {
    var inner = m * 2;

    if (m == 1) continue;
    if (m == 3) break;

    print inner;  // 0, 4
  }

  // ---------- 7. Ƕ�� while + continue + break ----------
  var outer = 0;
  while (outer < 2) {
    var inner = 0;

    while (inner < 3) {
      inner = inner + 1;
      var tmp = outer * 10 + inner;

      if (inner == 2) continue;
      break;
    }

    print outer;   // 0, 1
    outer = outer + 1;
  }

  print outer;     // 2

  )";

  // �ʷ�����
  Lexer lexer(source);
  std::vector<Token> tokens = lexer.ScanAll();

  // �﷨����
  Parser parser(tokens);
  std::vector<StmtPtr> program = parser.ParseProgram();

  // �����ֽ���
  Generator generator;
  Function main_fn = generator.Generate(program);

  // ִ��
  VM vm;
  vm.Run(main_fn);

  std::cout << "===== Scope ð�̲��Խ��� =====\n";
}

void CallFunctionSmokeTest() {
  using namespace cilly;

  std::cout << "===== Return ð�̲��� =====\n";

  /* std::string source =
   * ReadFileToString("D:/dev/cilly-vm-cpp/cilly_vm_cpp/file.txt");          */
  std::string source = R"(
print "BEGIN";
print 111;

fun add(a, b) { return a + b; }
print add(1, 2);
print add(20, 22);

fun sub(a, b) { return a - b; }
print sub(10, 7);

fun abs1(x) {
  if (x < 0) { return 0 - x; }
  else { return x; }
}
print abs1(9);
print abs1(0 - 9);

fun fact(n) {
  if (n < 2) { return 1; }
  return n * fact(n - 1);
}
print fact(5);

print add(add(1, 2), add(3, 4));
print add(fact(3), fact(4));

fun shadow(x) {
  var y = x + 1;
  {
    var y = 100;
  }
  return y;
}
print shadow(9);

fun sum_skip3(n) {
  var i = 0;
  var s = 0;
  while (i < n) {
    i = i + 1;
    if (i == 3) { continue; }
    if (i == 8) { break; }
    s = s + i;
  }
  return s;
}
print sum_skip3(100);

fun list_demo(a) {
  var L = [a, a + 1, a + 2];
  L[1] = L[1] + 10;
  return L[0] + L[1] + L[2];
}
print list_demo(1);

fun dict_demo(dummy) {
  var D = { "a": 1, "b": 2 };
  D["c"] = D["a"] + D["b"];
  return D["c"];
}
print dict_demo(0);

fun for_demo(n) {
  var s = 0;
  for (var i = 0; i < n; i = i + 1) {
    s = s + i;
  }
  return s;
}
print for_demo(5);

print 999;
print "END";
)";

  // �ʷ�����
  Lexer lexer(source);
  std::vector<Token> tokens = lexer.ScanAll();

  // �﷨����
  Parser parser(tokens);
  std::vector<StmtPtr> program = parser.ParseProgram();

  // �����ֽ���
  Generator generator;
  Function main_fn = generator.Generate(program);

  // ִ��
  VM vm;
  RegisterBuiltins(vm);
  for (const auto& fnptr : generator.Functions()) {
    vm.RegisterFunction(fnptr.get());  // ע�����б���ĺ���
  }

  vm.Run(main_fn);

  std::cout << "===== Scope ð�̲��Խ��� =====\n";
}

void NativeFunctionSmokeTest() {
  using namespace cilly;

  std::cout << "===== Full Smoke Test (Native + User Functions) =====\n";

  std::string source = R"(
print "BEGIN_FULL";

print len([1, 2, 3]);
print str(123);
print type({ "a": 1 });
print abs(0 - 9);
print clock();

fun add(a, b) { return a + b; }
print add(1, 2);
print add(20, 22);

fun fact(n) {
  if (n < 2) { return 1; }
  return n * fact(n - 1);
}
print fact(5);

fun isEven(n) {
  if (n == 0) return true;
  return isOdd(n - 1);
}
fun isOdd(n) {
  if (n == 0) return false;
  return isEven(n - 1);
}
print isEven(10);
print isOdd(10);
print isEven(7);
print isOdd(7);

fun shadow(x) {
  var y = x + 1;
  {
    var y = 100;
  }
  return y;
}
print shadow(9);

fun sum_skip3(n) {
  var i = 0;
  var s = 0;
  while (i < n) {
    i = i + 1;
    if (i == 3) { continue; }
    if (i == 8) { break; }
    s = s + i;
  }
  return s;
}
print sum_skip3(100);

fun list_demo(a) {
  var L = [a, a + 1, a + 2];
  L[1] = L[1] + 10;
  return L[0] + L[1] + L[2];
}
print list_demo(1);

fun dict_demo(dummy) {
  var D = { "a": 1, "b": 2 };
  D["c"] = D["a"] + D["b"];
  return D["c"];
}
print dict_demo(0);

print 999;
print "END_FULL";
)";

  Lexer lexer(source);
  std::vector<Token> tokens = lexer.ScanAll();

  Parser parser(tokens);
  std::vector<StmtPtr> program = parser.ParseProgram();

  Generator generator;
  Function main_fn = generator.Generate(program);

  VM vm;

  // builtins ������ע�ᣬռ�� 0..4
  RegisterBuiltins(vm);

  for (const auto& fnptr : generator.Functions()) {
    vm.RegisterFunction(fnptr.get());
  }

  vm.Run(main_fn);

  std::cout << "===== Full Smoke Test END =====\n";
}

void CallVirtualFunctionTest() {
  using namespace cilly;

  std::cout << "===== CallVirtualFunctionTest BEGIN =====\n";

  //  ��Ҫ�� // ע�ͣ����� lexer ��֧��
  std::string source = R"(
print "BEGIN_CALLV";

fun add(a, b) { return a + b; }

var f = add;
print f(1, 2);

var o = { "m": add };
print o["m"](20, 22);

print add(3, 4);

print len([1, 2, 3]);
print abs(0 - 9);
print clock();

print "END_CALLV";
)";

  // �ʷ�����
  Lexer lexer(source);
  std::vector<Token> tokens = lexer.ScanAll();

  // �﷨����
  Parser parser(tokens);
  std::vector<StmtPtr> program = parser.ParseProgram();

  // �����ֽ���
  Generator generator;
  Function main_fn = generator.Generate(program);

  // VM ִ��
  VM vm;

  //  ���룺��ע�� builtin��������Ѿ����� builtin index ǰ׺��
  // ������������ĳ�����Ŀ��ʵ�ʵģ�RegisterBuiltins / RegisterNativeBuiltins
  // ...
  RegisterBuiltins(vm);

  // ��ע���û�������˳������� Generator::Functions() һ�£�
  for (const auto& fnptr : generator.Functions()) {
    vm.RegisterFunction(fnptr.get());
  }

  vm.Run(main_fn);

  std::cout << "===== CallVirtualFunctionTest END =====\n";
}

void RunUnitTests() {
  ValueTest();
  StackTest();
  ChunkTest();
  FunctionTest();
}

void RunVMTests() {
  VMTest();
  VarTest();
  CallTest();
  CallWithArgTest();
  Eqtest();
  ForLoopTest();
  IfTest();
  OddEvenTest();
  CompareTest();
}

void RunOpcodeTests() {
  ListOpcodeTest();
  DictOpcodeTest();
}

void RunFrontendTests() {
  LexerSmokeTest();
  ParserExprSmokeTest();
}

void RunEndToEndTests() {
  FrontendEndToEndTest();
  FrontendEndToEndBlockTest();
  FrontendETESmokeTest();
  ScopeAllFeatureSmokeTest();
  CallFunctionSmokeTest();
}

void NativeFunctionTest() {
  NativeFunctionSmokeTest();
  CallVirtualFunctionTest();
  CallVirtualFunctionTest();
}

int main() {
  std::cout << "=== cilly-vm-cpp test runner ===\n";
  NativeFunctionTest();
  RunEndToEndTests();
  RunFrontendTests();
  RunOpcodeTests();
  RunVMTests();
  RunUnitTests();

  return 0;
}
